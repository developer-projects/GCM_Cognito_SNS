
public class CommunicationConstants
{
    public static final String TAG = "GCM_Globals";
    public static final String GCM_SENDER_ID = "410546417645";
    public static final String BASE_URL = "https://android.googleapis.com/gcm/send";
    public static final String PREFS_NAME = "GCM_Communication";

    // replace it with your own gcm api key here
    public static final String GCM_API_KEY = "AIzaSyCp_HIE77Ka3FliwRrv8tXRfDnthcHjSW0";
    public static final int SIMPLE_NOTIFICATION = 22;
    public static final long GCM_TIME_TO_LIVE = 60L * 60L * 24L * 7L * 4L; // 4 Weeks
    public static int mode = 0;

    public static String alertText = "";
    public static String titleText = "";
    public static String contentText = "";

    public static final String AWS_DEVELOPER_CREDENTIAL_KEY = "AKIAJ3NVH57OQYGPMRII";
    public static final String AWS_DEVELOPER_CREDENTIAL_SECRETE = "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";

    //AWS_USERS_DATABASE_CONSTANTS
    public static final String REG_ID ="reg_id";
    public static final String ACTIVE = "active";
    public static final String ONLINE = "online";
    public static final String DATA_SET_NAME = "datasetName";
    public static final String SYNC_COUNT = "syncCount";
}