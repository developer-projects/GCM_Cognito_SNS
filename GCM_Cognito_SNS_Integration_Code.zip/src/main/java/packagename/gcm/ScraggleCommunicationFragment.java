package edu.neu.madcourse.vaishali_shah.gcm;

import android.app.AlertDialog;
import android.app.Fragment;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.amazonaws.mobileconnectors.cognito.Dataset;
import com.amazonaws.mobileconnectors.cognito.Record;
import com.amazonaws.mobileconnectors.cognito.SyncConflict;
import com.amazonaws.mobileconnectors.cognito.exceptions.DataStorageException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import packagename.R;
import packagename.AwsConstants;
import packagename.core.CognitoDataSetProvider;

/**
 * A placeholder fragment containing a simple view.
 */
public class ScraggleCommunicationFragment extends Fragment {
    private AlertDialog.Builder builder = null;
    private AlertDialog newUserDialog = null;
    private Map<String,UserDetails> onlineUsers = new HashMap<String,UserDetails>();
    private Gson gson = null;

    public ScraggleCommunicationFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        gson = new GsonBuilder().create();
        return inflater.inflate(R.layout.fragment_scraggle_communication, container, false);
    }

    private void listActiveUsers()
    {

    }

    public void addUser(final String regID)
    {
        final View dialogMenu = getActivity().getLayoutInflater().inflate(R.layout.comm_add_user,null);
        builder = new AlertDialog.Builder(getActivity());
        builder.setView(dialogMenu);
        newUserDialog = builder.create();
        ((Button)((LinearLayout) dialogMenu).getChildAt(1)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View addNewUser) {
                EditText userName = ((EditText) ((LinearLayout) dialogMenu).getChildAt(0));
                TextView errorMsg= ((TextView) ((LinearLayout) dialogMenu).getChildAt(2));
                if(userName.getText().equals(null) ||
                        userName.getText().toString().trim().equals("")){
                    errorMsg.setText("Please enter valid user name.");
                }
                else{
                    String user = userName.getText().toString();
                    UserDetails userDetails  = new UserDetails(true,
                            true,
                            regID);
                    String value = gson.toJson(userDetails);
                    addUserToCognito(user,value);
                }
            }
        });
        newUserDialog.show();
    }

    private void addUserToCognito(final String key, final String value){
       new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String msg = "Updating user to cognito DB";
                CognitoDataSetProvider instance = CognitoDataSetProvider.getInstance();
                Dataset dataset = instance.getDataSet(getActivity(), AwsConstants.AWS_DATASET_USERS);
                if (dataset == null) {
                    return null;
                }
                dataset.put(key, value);
                dataset.synchronizeOnConnectivity(new AddUserToCognito());
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {

            }
        }.execute(null, null, null);
    }

    private class AddUserToCognito implements Dataset.SyncCallback {

        @Override
        public void onSuccess(final Dataset dataset, final List<Record> records) {
            newUserDialog.dismiss();
        }

        @Override
        public boolean onConflict(Dataset dataset, List<SyncConflict> syncConflicts) {
            // TODO: Students need to handle conflict here
            return false;
        }
        @Override
        public boolean onDatasetDeleted(Dataset dataset, String s) {
            return false;
        }

        @Override
        public boolean onDatasetsMerged(Dataset dataset, List<String> strings) {
            // TODO: students need to handle merge problem here.
            return false;
        }

        @Override
        public void onFailure(final DataStorageException e) {
            System.out.println(e.getMessage());
        }
    }

    public void createNewUser(String regIDNewUser)
    {
        CognitoDataSetProvider instance = CognitoDataSetProvider.getInstance();
        Dataset dataset = instance.getDataSet(getActivity(), AwsConstants.AWS_DATASET_USERS);
        if (dataset == null) {
            throw new Error("Dataset is null");
        }
        dataset.synchronizeOnConnectivity(new RetrieveUserFromCognito(regIDNewUser));

    }

    private class RetrieveUserFromCognito implements Dataset.SyncCallback {
        String regIDNewUser = null;
        public RetrieveUserFromCognito(String regIDNewUser){
            this.regIDNewUser = regIDNewUser;
        }
        @Override
        public void onSuccess(final Dataset dataset, final List<Record> records) {
            Map<String,String> users =  dataset.getAll();
            Boolean userExists = false;
           if(users != null && users.size() > 0)
           {
               Iterator<String> itr = users.keySet().iterator();
               while(itr.hasNext()){
                   Map<String, Object> userDetails = new HashMap<String, Object>();
                   String user = itr.next();
                   String attributes = users.get(user);
                   UserDetails details =  gson.fromJson(attributes, UserDetails.class);
                   if(details.getOnline() && details.getActive()){
                       onlineUsers.put(user, details);
                   }
                   if(details.getActive().equals(regIDNewUser)){
                       userExists = true;
                   }
               }
           }
           if(!userExists){
               getActivity().runOnUiThread(new Runnable() {
                   @Override
                   public void run() {
                       addUser(regIDNewUser);
                   }
               });
           }
           else{
               getActivity().runOnUiThread(new Runnable() {
                   @Override
                   public void run() {
                       listActiveUsers();
                   }
               });
           }
        }

        @Override
        public boolean onConflict(Dataset dataset, List<SyncConflict> syncConflicts) {
            // TODO: Students need to handle conflict here
            return false;
        }
        @Override
        public boolean onDatasetDeleted(Dataset dataset, String s) {
            return false;
        }

        @Override
        public boolean onDatasetsMerged(Dataset dataset, List<String> strings) {
            // TODO: students need to handle merge problem here.
            return false;
        }

        @Override
        public void onFailure(final DataStorageException e) {
            System.out.println(e.getMessage());
        }
    }

    private class UserDetails{
        private Boolean active= null;
        private Boolean online = null;
        private String reg_id = null;

        public Boolean getActive() {
            return active;
        }
        public void setActive(Boolean active) {
            this.active = active;
        }
        public Boolean getOnline() {
            return online;
        }
        public void setOnline(Boolean online) {
            this.online = online;
        }
        public String getReg_id() {
            return reg_id;
        }
        public void setReg_id(String reg_id) {
            this.reg_id = reg_id;
        }

        public UserDetails(Boolean active, Boolean online, String reg_id){
            setActive(active);
            setOnline(online);
            setReg_id(reg_id);
        }
    }
}
