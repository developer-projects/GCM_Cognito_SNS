import android.app.IntentService;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.cognito.CognitoSyncManager;
import com.amazonaws.mobileconnectors.cognito.Dataset;
import com.amazonaws.mobileconnectors.cognito.PushSyncUpdate;
import com.amazonaws.regions.Regions;

import packagename.R;
import packagename.ScraggleMultiplayerCommunication;
import packagename.core.CognitoDataSetProvider;

public class GcmIntentService extends IntentService {
	public static final int NOTIFICATION_ID = 1;
	private NotificationManager mNotificationManager;
	NotificationCompat.Builder builder;
	static final String TAG = "GCM_Communication";

	public GcmIntentService() {
		super("GcmIntentService");
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		String alertText = CommunicationConstants.alertText;
		String titleText = CommunicationConstants.titleText;
		String contentText = CommunicationConstants.contentText;
		if(intent.getAction().equals("com.google.android.c2dm.intent.RECEIVE")){
			CognitoDataSetProvider instance = CognitoDataSetProvider.getInstance();
			CognitoCachingCredentialsProvider credentialsProvider = instance.getCredentialsProvider();
			CognitoSyncManager syncManager = new CognitoSyncManager(getApplicationContext(), Regions.US_EAST_1,credentialsProvider);
			PushSyncUpdate update = syncManager.getPushSyncUpdate(intent);
			String dataSetName = update.getDatasetName();
			long syncCount = update.getSyncCount();
			Intent multiPlayerCommunicationIntent = new Intent(getApplicationContext(),
					ScraggleMultiplayerCommunication.class);
			multiPlayerCommunicationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            multiPlayerCommunicationIntent.putExtra(CommunicationConstants.DATA_SET_NAME,dataSetName);
            multiPlayerCommunicationIntent.putExtra(CommunicationConstants.SYNC_COUNT,Long.toString(syncCount));
            getApplicationContext().startActivity(multiPlayerCommunicationIntent);
		}
		else if(intent.getAction().equals("com.google.android.c2dm.intent.REGISTRATION")){
			Bundle extras = intent.getExtras();
			Log.d(String.valueOf(extras.size()), extras.toString());
			if (!extras.isEmpty()) {
				sendNotification(alertText, titleText, contentText);
			}
		}

		// Release the wake lock provided by the WakefulBroadcastReceiver.
		GcmBroadcastReceiver.completeWakefulIntent(intent);
	}

	// Put the message into a notification and post it.
	// This is just one simple example of what you might choose to do with
	// a GCM message.
	public void sendNotification(String alertText, String titleText,
			String contentText) {
		mNotificationManager = (NotificationManager) this
				.getSystemService(Context.NOTIFICATION_SERVICE);
		Intent notificationIntent;
		notificationIntent = new Intent(this,
				edu.neu.madcourse.vaishali_shah.gcm.CommunicationMain.class);
		notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		notificationIntent.putExtra("show_response", "show_response");
		PendingIntent intent = PendingIntent.getActivity(this, 0, new Intent(
				this, CommunicationMain.class),
				PendingIntent.FLAG_UPDATE_CURRENT);

		NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(
				this)
				.setSmallIcon(R.drawable.ic_stat_cloud)
				.setContentTitle(titleText)
				.setStyle(
						new NotificationCompat.BigTextStyle()
								.bigText(contentText))
				.setContentText(contentText).setTicker(alertText)
				.setAutoCancel(true);
		mBuilder.setContentIntent(intent);
		mNotificationManager.notify(NOTIFICATION_ID, mBuilder.build());
	}

}