
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.cognito.CognitoSyncManager;
import com.amazonaws.mobileconnectors.cognito.Dataset;
import com.amazonaws.mobileconnectors.cognito.Record;
import com.amazonaws.mobileconnectors.cognito.SyncConflict;
import com.amazonaws.mobileconnectors.cognito.exceptions.DataStorageException;
import com.amazonaws.mobileconnectors.cognito.exceptions.RegistrationFailedException;
import com.amazonaws.mobileconnectors.cognito.exceptions.SubscribeFailedException;
import com.amazonaws.regions.Regions;

import java.util.ArrayList;
import java.util.List;

import packagename.core.CognitoConfigContract;
import packagename.core.CognitoDataSetProvider;
import packagename.core.CognitoKeyValue;

public class CognitoDevAuthSample extends Activity implements CognitoDataSetProvider.OnProviderInitResultCallback {


    public CognitoDevAuthSample()
    {
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onSuccess() {
        Toast.makeText(this, "Successfully init CognitoDatasetProvider", Toast.LENGTH_LONG).show();
        registerDevice();
    }

    @Override
    public void onFailure(String s) {
        Toast.makeText(this, "Failed to init CognitoDatasetProvider", Toast.LENGTH_LONG).show();
    }

    private ListView lvKeyValuePairs = null;
    private EditText etKey = null;
    private EditText etValue = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    private void subscribeToDataSet(){
        new AsyncTask<Void, Void, String>() {
            CognitoDataSetProvider instance = CognitoDataSetProvider.getInstance();
            CognitoCachingCredentialsProvider credentialsProvider = instance.getCredentialsProvider();
            CognitoSyncManager syncManager = new CognitoSyncManager(getApplicationContext(), Regions.US_EAST_1,credentialsProvider);

            @Override
            protected String doInBackground(Void... params) {
                String msg = "Subscribed successfully.";
                if(syncManager.isDeviceRegistered()){
                    System.out.println("Device is registered successfully.");
                    Dataset dataset = syncManager.openOrCreateDataset(AwsConstants.AWS_DATASET_NAME);
                    try{
                        dataset.subscribe();
                    }

                    catch (SubscribeFailedException sfe){
                        msg ="Error in subscription" + sfe.getMessage();
                        sfe.printStackTrace();
                    }
                    catch(AmazonClientException ace){
                        msg = "Error in subscription" + ace.getMessage();
                        ace.printStackTrace();
                    }
                }
                else{
                    System.out.println("Device not registered.");
                }
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                System.out.println(msg);

            }
        }.execute(null, null, null);
    }

    private void registerDevice(){
        new AsyncTask<Void, Void, String>() {
            CognitoDataSetProvider instance = CognitoDataSetProvider.getInstance();
            CognitoCachingCredentialsProvider credentialsProvider = instance.getCredentialsProvider();
            CognitoSyncManager syncManager = new CognitoSyncManager(getApplicationContext(), Regions.US_EAST_1,credentialsProvider);

            @Override
            protected String doInBackground(Void... params) {
                String msg = "Registered successfully.";
                try {
                    if(syncManager.isDeviceRegistered()){
                        syncManager.unregisterDevice();
                    }
                    String deviceRegId = getIntent().getStringExtra(AwsConstants.REG_ID);
                    syncManager.registerDevice(AwsConstants.GCM, deviceRegId);
                } catch (RegistrationFailedException rfe) {
                    msg = "failed to register" + rfe.getMessage();
                    Log.e(CognitoDevAuthSample.class.getName(), "Failed to register device for silent sync", rfe);
                } catch (AmazonClientException ace) {
                    msg = "failed to register" + ace.getMessage();
                    Log.e(CognitoDevAuthSample.class.getName(), "An unknown error caused registration for silent sync to fail",
                            ace);
                }
                catch(Exception ex){
                    msg = "failed to register" + ex.getMessage();
                    ex.printStackTrace();
                }
                return msg;
            }

            @Override
            protected void onPostExecute(String msg) {
                System.out.println(msg);
                subscribeToDataSet();
            }
        }.execute(null, null, null);
    }

    public void registerDeviceWithCognito() {
        if(CognitoDataSetProvider.getInstance() == null)
        {

            CognitoConfigContract contract = new CognitoConfigContract(
                    AwsConstants.AWS_ACCOUNT_ID,
                    AwsConstants.AWS_IDENTITY_POOL_ID,
                    AwsConstants.AWS_UNAUTH_ROLE_ARN,
                    AwsConstants.AWS_AUTH_ROLE_ARN,
                    AwsConstants.AWS_REGION,
                    AwsConstants.AWS_DEVELOPER_CREDENTIAL_KEY,
                    AwsConstants.AWS_DEVELOPER_CREDENTIAL_SECRETE,
                    AwsConstants.AWS_DEVELOPER_PROVIDER_NAME);
            CognitoDataSetProvider.initialize(this, contract, this);
        }
        registerDevice();

    }


    private void onSync() {
        String key = etKey.getText().toString();
        String value = etValue.getText().toString();
        CognitoDataSetProvider instance = CognitoDataSetProvider.getInstance();
        if (instance == null) {
            Toast.makeText(this, "CognitoDataSetProvider is null", Toast.LENGTH_LONG).show();
            return;
        }
        Dataset dataset = CognitoDataSetProvider.getInstance().getDataSet(this, AwsConstants.AWS_DATASET_NAME);
        if (dataset == null) {
            Toast.makeText(this, "Dataset is null", Toast.LENGTH_LONG).show();
            return;
        }
        if (key != null && !key.isEmpty() && value != null && !value.isEmpty()) {
            dataset.put(key, value);
            dataset.synchronizeOnConnectivity(new DatasetSyncCallback());
        }
    }



    private class DatasetSyncCallback implements Dataset.SyncCallback {

        @Override
        public void onSuccess(final Dataset dataset, final List<Record> records) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(CognitoDevAuthSample.this, "Sync successfully", Toast.LENGTH_LONG).show();
                    ArrayList<CognitoKeyValue> data = new ArrayList<CognitoKeyValue>();
                    for (Record record : dataset.getAllRecords())
                        data.add(new CognitoKeyValue(record.getKey(), record.getValue()));

                }
            });
        }

        @Override
        public boolean onConflict(Dataset dataset, List<SyncConflict> syncConflicts) {
            // TODO: Students need to handle conflict here
            return false;
        }

        @Override
        public boolean onDatasetDeleted(Dataset dataset, String s) {
            return false;
        }

        @Override
        public boolean onDatasetsMerged(Dataset dataset, List<String> strings) {
            // TODO: students need to handle merge problem here.
            return false;
        }

        @Override
        public void onFailure(final DataStorageException e) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(CognitoDevAuthSample.this, "Sync failed : " + e.toString(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
