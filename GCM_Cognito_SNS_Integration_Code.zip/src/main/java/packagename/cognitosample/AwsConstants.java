
import com.amazonaws.regions.Regions;

public class AwsConstants {
    public static final String AWS_ACCOUNT_ID = "xxxxxxxxxxx";
    public static final String AWS_IDENTITY_POOL_ID = "us-east-1:aea64ea2-2f5c-4c25-a9fd-2698953895e3";
    public static final String AWS_UNAUTH_ROLE_ARN = "arn:aws:iam::186007481815:role/Cognito_TICTACTOE_NVirginiaUnauth_Role";
    public static final String AWS_AUTH_ROLE_ARN = "arn:aws:iam::186720081815:role/Cognito_PushSync_Role";
   
    public static final Regions AWS_REGION = Regions.US_EAST_1;
    public static final String AWS_DATASET_NAME = "TestDataSet";
    public static final String AWS_DATASET_USERS = "Users";


    // AWS Developer credentials.
    public static final String AWS_DEVELOPER_CREDENTIAL_KEY = "AKIA99NVH57OQYGPMRYQ";
        public static final String AWS_DEVELOPER_CREDENTIAL_SECRETE = "bfd5j99qbOV5UWZWHCCQ8IVXMrz1bzD6N4EGX4zD";
    // Cognito Identity Pool's developer provider name, must match the identity pool's developper provider name you set.
    public static final String AWS_DEVELOPER_PROVIDER_NAME = "edu.xyz.course";
    // Set the developer authentication mode's domain. It is just String value set by you.
    public static final String AWS_DEV_AUTH_DOMAIN = "domain.developer.com";

    public static final String GCM = "GCM";
    public static final String REG_ID ="REG_ID";
}
