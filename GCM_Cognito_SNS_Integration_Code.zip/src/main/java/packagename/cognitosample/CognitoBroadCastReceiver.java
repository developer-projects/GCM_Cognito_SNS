import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.cognito.CognitoSyncManager;
import com.amazonaws.mobileconnectors.cognito.Dataset;
import com.amazonaws.mobileconnectors.cognito.PushSyncUpdate;
import com.amazonaws.mobileconnectors.cognito.Record;
import com.amazonaws.mobileconnectors.cognito.SyncConflict;
import com.amazonaws.mobileconnectors.cognito.exceptions.DataStorageException;
import com.amazonaws.regions.Regions;
import java.util.List;
import packagename.core.CognitoDataSetProvider;

public class CognitoBroadCastReceiver extends BroadcastReceiver {
    public CognitoBroadCastReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.

        CognitoDataSetProvider instance = CognitoDataSetProvider.getInstance();
        CognitoCachingCredentialsProvider credentialsProvider = instance.getCredentialsProvider();
        CognitoSyncManager client = new CognitoSyncManager(context.getApplicationContext(), Regions.US_EAST_1,credentialsProvider);

        PushSyncUpdate update = client.getPushSyncUpdate(intent);
        // The update has the source (cognito-sync here), identityId of the
        // user, identityPoolId in question, the non-local sync count of the
        // data set and the name of the dataset. All are accessible through
        // relevant getters.
        String source = update.getSource();
        String identityPoolId = update.getIdentityPoolId();
        String identityId = update.getIdentityId();
        String datasetName = update.getDatasetName();
        long syncCount = update.getSyncCount();
        Dataset dataset = client.openOrCreateDataset(datasetName);
        // need to access last sync count. If sync count is less or equal to
        // last sync count of the dataset, no sync is required.
        long lastSyncCount = dataset.getLastSyncCount();
        if (lastSyncCount < syncCount) {
            dataset.synchronize(new Dataset.SyncCallback() {
                @Override
                public void onSuccess(Dataset dataset, List<Record> list) {

                }

                @Override
                public boolean onConflict(Dataset dataset, List<SyncConflict> list) {
                    return false;
                }

                @Override
                public boolean onDatasetDeleted(Dataset dataset, String s) {
                    return false;
                }

                @Override
                public boolean onDatasetsMerged(Dataset dataset, List<String> list) {
                    return false;
                }

                @Override
                public void onFailure(DataStorageException e) {

                }
            });
        }}
}
